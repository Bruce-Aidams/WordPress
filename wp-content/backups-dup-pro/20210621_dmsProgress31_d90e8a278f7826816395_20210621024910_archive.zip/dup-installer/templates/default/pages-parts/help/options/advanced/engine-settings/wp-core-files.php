<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">WP Core Files</td>
    <td>
        To skip extraction of WordPress core files, enable this switch.
    </td>
</tr>