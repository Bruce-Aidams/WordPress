<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Password</td>
    <td>The new password for the new user.  Must be at least 6 characters long.</td>
</tr>