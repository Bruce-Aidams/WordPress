<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">WP_CACHE</td>
    <td>
        Turn off Cache support for WordPress. This sets WP_CACHE in your wp-config file to false if true, otherwise it will create the setting if not set.  The "Keep Home Path"
        sets WPCACHEHOME in your wp-config file to nothing if true, otherwise nothing is changed.
    </td>
</tr>