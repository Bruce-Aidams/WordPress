<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">FORCE_SSL_ADMIN</td>
    <td>
        Turn off SSL support for WordPress. This sets FORCE_SSL_ADMIN in your wp-config file to false if true, otherwise it will create the setting if not set.  The "Enforce on Login"
        will turn off SSL support for WordPress Logins.
    </td>
</tr>