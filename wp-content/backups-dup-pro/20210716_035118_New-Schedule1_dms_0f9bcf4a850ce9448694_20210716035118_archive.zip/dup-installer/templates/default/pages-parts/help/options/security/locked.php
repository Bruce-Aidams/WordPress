<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Locked</td>
    <td>
        "Locked" means a password is protecting each step of the installer. This option is recommended on all installers that are accessible via a public URL but not required.
    </td>
</tr>